/*
*StudentsUnionApp
*@author Sabrina Rosa
*11/10/22
*/

import javax.swing.JOptionPane;
public class StudentsUnionApp{

    public static void main(String args[]){
        int totalCost;
		int numShirts, numCaps, numHoodies;
		int tShirts, tCaps, tHoodies;

	    //Input
	    numShirts = Integer.parseInt(JOptionPane.showInputDialog (null, " Inform the number of shirts "));
	    StudentsUnion.setNumShirts (numShirts);

	    numCaps = Integer.parseInt(JOptionPane.showInputDialog (null, " Inform the number of caps "));
	    StudentsUnion.setNumCaps (numCaps);

	    numHoodies = Integer.parseInt (JOptionPane.showInputDialog (null, " Inform the number of hoodies "));
	    StudentsUnion.setNumHoodies (numHoodies);

	    //Compute
		StudentsUnion.compute();
		numShirts = StudentsUnion.getNumShirts();
		numCaps = StudentsUnion.getNumCaps();
		numHoodies = StudentsUnion.getNumHoodies();

	    //Output
	    total = StudentsUnion.getTotal;
	    JOptionPane.showMessageDialog (null, "Total Shirts " + tShirts + ",Total Caps " + TCaps +  ",Total Hoodies"
	    + tHoodies);


	}//main

}//class