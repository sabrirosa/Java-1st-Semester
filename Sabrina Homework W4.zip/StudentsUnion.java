/*
*StudentsUnion
*@author Sabrina Rosa
*11/10/22
*/

public class StudentsUnion {
	//Declare variables
	private int totalCost;
	private int numShirts, numCaps, numHoodies;
	int tShirts, tCaps, tHoodies;

	//Compute
	public void compute (){
	tShirts = numShirts * 5;
	tCaps = numCaps * 10;
	tHoodies = numHoodies * 20;

	}

	//Getters and setters
	public void setNumCaps (int numCaps){
		this.numCaps = numCaps;
	}

	public void setNumShirts (int numShirts){
		this.numShirts = numShirts;
	}

	public void setNumHoodies (int numHoodie){
		this.numHoodies = numHoodies;

 	}
	public int getTotalCost (){
		return totalCost = totalCost;

	}
}