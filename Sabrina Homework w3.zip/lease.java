/*
 *lease.java
 *@author Sabrina Rosa de Oliveira
 *06/10/2022
 */

 public class lease {

 	private int amount, year;
 	private double fee, totalT, total;

	 public lease() {
		amount = 0;
		year = 0;
		fee = 0;
		totalT = 0;
		total = 0;
	 }

	 public void setAmount(int money){
		 this.amount = amount;
	 }
	 public void setYear(int year){
		 this.year = year;
	 }
	 public void setFee(double tax){
		 this.fee = fee;
	 }
	 public void setTotalT(double totalT){
		 this.totalT = totalT;
	 }
	 public void setTotal(double total){
		 this.total = total;
	 }

	 public void compute(){
		fee = amount*0.03;
		totalT = fee*year;
		total = amount+totalT;
	 }

	 public int getAmount(){
		return amount;
	 }

	 public int getYear(){
		return year;
	 }

	 public double getFee(){
		return fee;
	 }

	 public double getTotalT(){
		return totalT;
	 }

	 public double getTotal(){
		return total;
	 }
}