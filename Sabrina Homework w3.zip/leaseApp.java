/*
 *leaseApp.java
 *@author Sabrina Rosa de Oliveira
 *06/10/2022
 */

import javax.swing.JOptionPane;

 public class leaseApp {
	public static void main (String args[]){

	int amount, year;
 	double fee, totalT, total;

		lease ln = new lease();

		amount = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the amount of money borrowed"));

		ln.setAmount(amount);
		year = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the numbers of years to return"));
		ln.setYear(year);

		ln.compute();

		amount = ln.getAmount();
		year = ln.getYear();
		fee = ln.getFee();
		totalT = ln.getTotalT();
		total = ln.getTotal();

		JOptionPane.showMessageDialog(null, "Enter the amount of money borrowed" + amount + "\n" +
		"To be paid within " + year + " year(s)" + "\n" +
		"The amount of fee to be paid will be " + fee + "per year" +
		", and the total amount of fees at the end of the lease will be " + totalT + "\n" +
		"You will pay the total of" + total);
	}
}